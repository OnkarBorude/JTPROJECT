package GuesserGame;
import java.util.*;

class Guesser{
	int Guessernum;
	public int guessnum() {
		System.out.println("enter guessser num : ");
		Scanner sc=new Scanner(System.in);
		Guessernum=sc.nextInt();
		return Guessernum;
	}
}

class Player{
	int playernum;
	
	
	public int takeplayernum() {
	System.out.println("enter player number ");
	Scanner sc=new Scanner(System.in);
	playernum=sc.nextInt();
	return playernum;
	
}
}
class Umpire{
	int guessernumber;
	int playernum1;
	int playernum2;
	int playernum3;
	
	public void takegussernum() {
	Guesser g=new Guesser();
	guessernumber=g.guessnum();
	}
	public void takeplayernumber() {
		Player p1=new Player();
		playernum1=p1.takeplayernum();
		
		Player p2=new Player();
		playernum2=p2.takeplayernum();
		
		Player p3=new Player();
		playernum3=p3.takeplayernum();
	}
	
	public void comapare() {
		if(guessernumber==playernum1) {
			if(guessernumber==playernum2) {
				System.out.println("player1 and player2 won");
			}
			else if(guessernumber==playernum3) {
				System.out.println("player1 and player3 won");
			}
			else if(guessernumber==playernum2 && guessernumber==playernum3) {
				System.out.println("player1 player2 and player3 won ");
			}
			else {
				System.out.println("player 1 won ");
			}
		}
		else if(guessernumber==playernum2) {
			if(guessernumber==playernum3) {
				System.out.println("player2 and player3 won");
			}
			else {
				System.out.println("player 2 won");
			}
		}
		else if(guessernumber==playernum3) {
			System.out.println("player 3 won game");
		}
		else {
			System.out.println("all are lose the game");
		}
	}
}


public class Game {

	public static void main(String[] args) {
		 Umpire u=new  Umpire();
		 Scanner sc=new Scanner(System.in);
		 System.out.println("enter number of output : ");
		 int n=sc.nextInt();
		 for(int i=0;i<n;i++) {
		 u.takegussernum();
		 u.takeplayernumber();
		 u.comapare();
		 }
    
	

}
}
