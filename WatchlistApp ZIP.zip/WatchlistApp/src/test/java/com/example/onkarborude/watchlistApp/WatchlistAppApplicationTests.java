package com.example.onkarborude.watchlistApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WatchlistAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
