package com.example.onkarborude.watchlistApp.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import com.example.onkarborude.watchlistApp.Entity.Movie;
import com.example.onkarborude.watchlistApp.Services.DatabaseService;

import jakarta.validation.Valid;

@RestController
public class MovieController {
	@Autowired
	DatabaseService databaseService;
	
	@GetMapping("/watchlistItemForm")
	public ModelAndView showKro(@RequestParam(required = false) Integer id) {
		String viewName="watchlistItemForm";
		
		Map<String, Object> model=new HashMap<>();
		if(id==null) {
			model.put("watchlistItem", new Movie());
		}
		else {
			model.put("watchlistItem", databaseService.getMovieById(id));
	
//		Movie dummy=new Movie();
//		dummy.setTitle("Gadar 2");
//		dummy.setRating(5.5f);
//		dummy.setPriority("low");
//		dummy.setComment("AVG MOVEI");
	//	model.put("watchlistItem", dummy);
		
		}
		return new ModelAndView(viewName, model);
	}
	
	
	@PostMapping("/watchlistItemForm")
	public ModelAndView submitForm(@Valid @ModelAttribute("watchlistItem") Movie movie, BindingResult bindingResult) {
		
		if(bindingResult.hasErrors()) {
			System.out.println(bindingResult.hasErrors());
			return new ModelAndView("watchlistItemForm");
		}
		
		Integer id=movie.getId();
		if(id==null) {
			databaseService.create(movie);
		}
		else {
			databaseService.update(movie, id);
		}
		
		
		RedirectView rd=new RedirectView();
		rd.setUrl("/watchlist");
		
		return new ModelAndView(rd);
	}

	@GetMapping("/watchlist")
	public ModelAndView getWatchlist() {
		
		String viewName="watchlist";
		Map<String, Object> model=new HashMap<>();
		List<Movie> movieList=databaseService.getAllMovie();
		model.put("watchlistrows", movieList );
		model.put("noofmovie", movieList.size());
		return new ModelAndView(viewName, model);
	}
	

}
